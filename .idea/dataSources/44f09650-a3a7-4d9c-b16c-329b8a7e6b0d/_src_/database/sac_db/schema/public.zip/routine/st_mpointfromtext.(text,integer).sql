create function st_mpointfromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END

$$;
