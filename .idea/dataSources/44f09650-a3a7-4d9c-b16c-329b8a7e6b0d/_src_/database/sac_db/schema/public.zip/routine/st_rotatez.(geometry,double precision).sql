create function st_rotatez(geometry, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Rotate($1, $2)
$$;
