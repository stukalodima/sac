create function st_pixelaspolygon(rast raster, x integer, y integer) returns geometry
LANGUAGE SQL
AS $$
SELECT geom FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;
