create function st_hillshade(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, azimuth double precision DEFAULT 315.0, altitude double precision DEFAULT 45.0, max_bright double precision DEFAULT 255.0, scale double precision DEFAULT 1.0, interpolate_nodata boolean DEFAULT false) returns raster
LANGUAGE SQL
AS $$
SELECT public.ST_hillshade($1, $2, NULL::raster, $3, $4, $5, $6, $7, $8)
$$;
