create function st_intersects(rast raster, geom geometry, nband integer DEFAULT NULL::integer) returns boolean
LANGUAGE SQL
AS $$
SELECT $1::geometry && $2 AND _st_intersects($2, $1, $3)
$$;
