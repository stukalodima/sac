create function st_mapalgebrafct(rast raster, pixeltype text, onerastuserfunc regprocedure) returns raster
LANGUAGE SQL
AS $$
SELECT st_mapalgebrafct($1, 1, $2, $3, NULL)
$$;
