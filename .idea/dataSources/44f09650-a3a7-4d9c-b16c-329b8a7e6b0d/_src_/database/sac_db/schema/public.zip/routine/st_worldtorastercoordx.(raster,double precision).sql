create function st_worldtorastercoordx(rast raster, xw double precision) returns integer
LANGUAGE SQL
AS $$
SELECT columnx FROM _st_worldtorastercoord($1, $2, NULL)
$$;
