create function geometry_contained_by_raster(geometry, raster) returns boolean
LANGUAGE SQL
AS $$
select $1 @ $2::geometry
$$;
