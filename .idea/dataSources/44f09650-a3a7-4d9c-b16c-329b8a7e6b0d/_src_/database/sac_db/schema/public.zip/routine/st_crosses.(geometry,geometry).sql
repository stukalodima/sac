create function st_crosses(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Crosses($1,$2)
$$;
