create function st_valuecount(rast raster, nband integer, exclude_nodata_value boolean, searchvalue double precision, roundto double precision DEFAULT 0) returns integer
LANGUAGE SQL
AS $$
SELECT ( public._ST_valuecount($1, $2, $3, ARRAY[$4]::double precision[], $5)).count
$$;
