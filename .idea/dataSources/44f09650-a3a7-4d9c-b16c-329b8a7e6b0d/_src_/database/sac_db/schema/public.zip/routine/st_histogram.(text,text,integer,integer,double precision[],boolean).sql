create function st_histogram(rastertable text, rastercolumn text, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
LANGUAGE SQL
AS $$
SELECT public._ST_histogram($1, $2, $3, TRUE, 1, $4, $5, $6)
$$;
