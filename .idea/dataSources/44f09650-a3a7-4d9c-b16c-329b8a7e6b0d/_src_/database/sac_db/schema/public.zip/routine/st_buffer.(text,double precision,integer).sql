create function st_buffer(text, double precision, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Buffer($1::public.geometry, $2, $3);
$$;
