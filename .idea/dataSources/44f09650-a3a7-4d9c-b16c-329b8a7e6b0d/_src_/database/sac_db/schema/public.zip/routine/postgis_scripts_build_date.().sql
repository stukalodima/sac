create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2016-07-05 13:05:08'::text AS version
$$;
