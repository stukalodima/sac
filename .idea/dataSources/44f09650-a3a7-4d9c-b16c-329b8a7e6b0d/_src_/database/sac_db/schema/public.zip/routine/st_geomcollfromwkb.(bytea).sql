create function st_geomcollfromwkb(bytea) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE
	WHEN geometrytype(ST_GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;
