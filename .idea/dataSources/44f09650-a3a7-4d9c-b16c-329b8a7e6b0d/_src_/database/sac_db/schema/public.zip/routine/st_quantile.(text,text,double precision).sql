create function st_quantile(rastertable text, rastercolumn text, quantile double precision) returns double precision
LANGUAGE SQL
AS $$
SELECT (_st_quantile($1, $2, 1, TRUE, 1, ARRAY[$3]::double precision[])).value
$$;
