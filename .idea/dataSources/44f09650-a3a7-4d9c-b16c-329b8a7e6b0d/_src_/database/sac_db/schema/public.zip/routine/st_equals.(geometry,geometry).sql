create function st_equals(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 ~= $2 AND _ST_Equals($1,$2)
$$;
