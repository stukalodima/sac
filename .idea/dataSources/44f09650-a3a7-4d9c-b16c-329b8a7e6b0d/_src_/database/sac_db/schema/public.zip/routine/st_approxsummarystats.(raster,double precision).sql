create function st_approxsummarystats(rast raster, sample_percent double precision) returns summarystats
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, 1, TRUE, $2)
$$;
