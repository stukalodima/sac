create function transliterate_ru_en(character varying) returns character varying
LANGUAGE plpgsql
AS $fun$
BEGIN
			RETURN replace(
				replace(
					replace(
						replace(
							replace(
								replace(
									replace(
										replace(
											translate(
												regexp_replace(
													regexp_replace(
														regexp_replace(
															lower($1), 
															$$['`’']$$, 
															'', 'g'),
														$$ье$$, 'ye'),
													$$ьё$$, 'ye'),
												$$абвгдеёзийклмнопрстуфъыьэ$$,
												$$abvgdeeziyklmnoprstuf"y'e$$ 	--"
												),
											'ж', 'zh'),
										'х', 'kh'),
									'ц', 'ts'),
								'ч', 'ch'),
							'ш', 'sh'),
						'щ', 'shch'),
					'ю', 'yu'),
				'я', 'ya');
		END;

$fun$;
