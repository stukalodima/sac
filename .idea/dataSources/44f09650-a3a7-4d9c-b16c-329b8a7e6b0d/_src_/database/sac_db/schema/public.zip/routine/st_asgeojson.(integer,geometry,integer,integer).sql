create function st_asgeojson(gj_version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
LANGUAGE SQL
AS $$
SELECT ST_AsGeoJson($2::geometry, $3::int4, $4::int4);
$$;
