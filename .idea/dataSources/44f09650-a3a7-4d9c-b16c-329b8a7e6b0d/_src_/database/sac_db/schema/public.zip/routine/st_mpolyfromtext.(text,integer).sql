create function st_mpolyfromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN ST_GeomFromText($1,$2)
	ELSE NULL END

$$;
