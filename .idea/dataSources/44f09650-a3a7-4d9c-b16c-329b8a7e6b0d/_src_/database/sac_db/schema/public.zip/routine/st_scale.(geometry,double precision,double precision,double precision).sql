create function st_scale(geometry, double precision, double precision, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Scale($1, ST_MakePoint($2, $3, $4))
$$;
