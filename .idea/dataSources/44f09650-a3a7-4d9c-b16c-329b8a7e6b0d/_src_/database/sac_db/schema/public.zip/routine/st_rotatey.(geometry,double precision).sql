create function st_rotatey(geometry, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)
$$;
