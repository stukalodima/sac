create function st_aspng(rast raster, nband integer, options text[] DEFAULT NULL::text[]) returns bytea
LANGUAGE SQL
AS $$
SELECT st_aspng(st_band($1, $2), $3)
$$;
