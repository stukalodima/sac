create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
LANGUAGE SQL
AS $$
select public.ST_distance( public.geography($1), public.geography($2),false)

$$;
