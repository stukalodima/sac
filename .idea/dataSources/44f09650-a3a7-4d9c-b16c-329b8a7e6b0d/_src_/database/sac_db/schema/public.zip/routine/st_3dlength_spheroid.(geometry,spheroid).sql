create function st_3dlength_spheroid(geometry, spheroid) returns double precision
LANGUAGE SQL
AS $$
SELECT _postgis_deprecate('ST_3DLength_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT ST_LengthSpheroid($1,$2);

$$;
