create function st_mpointfromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1)
	ELSE NULL END

$$;
