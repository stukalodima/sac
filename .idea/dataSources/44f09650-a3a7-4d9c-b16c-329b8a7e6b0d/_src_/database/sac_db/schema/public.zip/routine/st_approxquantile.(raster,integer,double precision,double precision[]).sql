create function st_approxquantile(rast raster, nband integer, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
LANGUAGE SQL
AS $$
SELECT _st_quantile($1, $2, TRUE, $3, $4)
$$;
