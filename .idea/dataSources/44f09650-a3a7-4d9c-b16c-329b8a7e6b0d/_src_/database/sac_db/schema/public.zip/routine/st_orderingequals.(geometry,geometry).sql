create function st_orderingequals(geometrya geometry, geometryb geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 ~= $2 AND _ST_OrderingEquals($1, $2)

$$;
