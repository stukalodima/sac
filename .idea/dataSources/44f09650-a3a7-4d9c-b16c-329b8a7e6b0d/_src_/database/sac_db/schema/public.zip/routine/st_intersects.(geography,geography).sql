create function st_intersects(geography, geography) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Distance($1, $2, 0.0, false) < 0.00001
$$;
