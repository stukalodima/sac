create function st_approxcount(rast raster, sample_percent double precision) returns bigint
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, 1, TRUE, $2)
$$;
