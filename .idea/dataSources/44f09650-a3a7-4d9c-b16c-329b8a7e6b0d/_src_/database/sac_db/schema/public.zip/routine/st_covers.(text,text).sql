create function st_covers(text, text) returns boolean
LANGUAGE SQL
AS $$
SELECT ST_Covers($1::geometry, $2::geometry);
$$;
