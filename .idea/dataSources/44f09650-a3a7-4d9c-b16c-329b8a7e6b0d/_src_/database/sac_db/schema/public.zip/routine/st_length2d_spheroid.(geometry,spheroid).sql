create function st_length2d_spheroid(geometry, spheroid) returns double precision
LANGUAGE SQL
AS $$
SELECT _postgis_deprecate('ST_Length2D_Spheroid', 'ST_Length2DSpheroid', '2.2.0');
    SELECT ST_Length2DSpheroid($1,$2);

$$;
