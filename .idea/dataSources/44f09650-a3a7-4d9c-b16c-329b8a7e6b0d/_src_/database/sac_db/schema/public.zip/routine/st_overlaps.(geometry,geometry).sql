create function st_overlaps(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Overlaps($1,$2)
$$;
