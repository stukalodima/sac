create function st_dumpvalues(rast raster, nband integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
LANGUAGE SQL
AS $$
SELECT valarray FROM st_dumpvalues($1, ARRAY[$2]::integer[], $3)
$$;
