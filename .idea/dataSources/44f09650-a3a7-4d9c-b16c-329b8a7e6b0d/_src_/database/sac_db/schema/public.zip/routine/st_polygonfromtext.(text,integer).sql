create function st_polygonfromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_PolyFromText($1, $2)
$$;
