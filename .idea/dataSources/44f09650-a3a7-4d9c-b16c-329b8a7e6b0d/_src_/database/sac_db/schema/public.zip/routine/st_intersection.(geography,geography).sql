create function st_intersection(geography, geography) returns geography
LANGUAGE SQL
AS $$
SELECT geography(ST_Transform(ST_Intersection(ST_Transform(geometry($1), _ST_BestSRID($1, $2)), ST_Transform(geometry($2), _ST_BestSRID($1, $2))), 4326))
$$;
