create function replace_ru_en(character varying) returns character varying
LANGUAGE plpgsql
AS $fun$
BEGIN
			RETURN translate(lower($1),
				$$ёйцукенгшщзхъфывапролджэячсмитьбю$$,
				$$`qwertyuiop[]asdfghjkl;'zxcvbnm,.$$	 				--`
				);
		END;

$fun$;
