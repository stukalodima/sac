create function replace_uk_en(character varying) returns character varying
LANGUAGE plpgsql
AS $fun$
BEGIN
			RETURN translate(lower($1),
				$$йцукенгшщзхїфівапролджєґячсмитьбю$$,
				$$qwertyuiop[]asdfghjkl;'\zxcvbnm,.$$ 					--'
				);
		END;

$fun$;
