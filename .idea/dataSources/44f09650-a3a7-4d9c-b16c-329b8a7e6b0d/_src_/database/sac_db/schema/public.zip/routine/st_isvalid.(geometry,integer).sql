create function st_isvalid(geometry, integer) returns boolean
LANGUAGE SQL
AS $$
SELECT (ST_isValidDetail($1, $2)).valid
$$;
