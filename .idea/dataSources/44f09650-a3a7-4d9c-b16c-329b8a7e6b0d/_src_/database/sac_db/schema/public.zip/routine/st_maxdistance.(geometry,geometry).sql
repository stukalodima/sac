create function st_maxdistance(geom1 geometry, geom2 geometry) returns double precision
LANGUAGE SQL
AS $$
SELECT _ST_MaxDistance(ST_ConvexHull($1), ST_ConvexHull($2))
$$;
