create function transliterate_uk_en(character varying) returns character varying
LANGUAGE plpgsql
AS $fun$
BEGIN
			RETURN replace(
				replace(
					replace(
						replace(
							replace(
								replace(
									replace(
										replace(
											replace(
												translate(
													regexp_replace(
														regexp_replace(
															regexp_replace(
																regexp_replace(
																	regexp_replace(
																		regexp_replace(
																			regexp_replace(
																				lower($1), 
																				$$['`’']$$, 
																				'', 'g'),
																			$$зг$$, 'zgh', 'g'),
																		$$^й$$, 'y'),
																	$$^ї$$, 'yi'),
																$$^є$$, 'ye'),
															$$^ю$$, 'yu'),
														$$^я$$, 'ya'),
													$$абвгґдезиіїйклмнопрстуфь$$,
													$$abvhgdezyiiiklmnoprstuf'$$ 	--'
													),
												'є', 'ie'),
											'ж', 'zh'),
										'х', 'kh'),
									'ц', 'ts'),
								'ч', 'ch'),
							'ш', 'sh'),
						'щ', 'shch'),
					'ю', 'iu'),
				'я', 'ia');
		END;

$fun$;
