create function add_word(word character varying, o_id integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE link integer;
		DECLARE w_id integer;
		BEGIN
			SELECT insert_word(word) INTO w_id;
			SELECT object_id INTO link FROM links WHERE object_id = o_id AND word_id = w_id;
			IF link IS NULL THEN
				INSERT INTO links(object_id, word_id) VALUES (o_id, w_id);
			END IF;
		END;

$$;
