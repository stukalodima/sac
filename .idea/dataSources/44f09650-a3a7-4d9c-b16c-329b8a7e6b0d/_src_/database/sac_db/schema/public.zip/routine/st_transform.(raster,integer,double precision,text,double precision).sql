create function st_transform(rast raster, srid integer, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
LANGUAGE SQL
AS $$
SELECT _st_gdalwarp($1, $4, $5, $2, $3, $3)
$$;
