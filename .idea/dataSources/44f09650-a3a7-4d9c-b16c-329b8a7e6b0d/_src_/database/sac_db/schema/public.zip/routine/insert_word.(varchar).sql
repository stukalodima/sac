create function insert_word(character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE w_id integer;
		BEGIN
			SELECT id INTO w_id FROM words WHERE word=$1;
			IF w_id IS NULL THEN
				INSERT INTO words(word) VALUES ($1) RETURNING id INTO w_id;
    		END IF;
    		RETURN w_id;
		END;

$$;
